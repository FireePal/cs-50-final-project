# NINJa Platformer
#### Video Demo:  <https://youtu.be/3c3wMlkbjvY?si=-DXGnrVyA3cGdwSv>
#### Description:

**INTRODUCTION :**
This is a platformer game built using the pygame library for Python. this project was done using a tutorial created by ** DAFluffyPotato ** .The tutorial provided the assets which included the image, sounds, Reference code along with the yoputube video guiding on how to build the game. This project was done following the guide
#### Explanation of the Game
The game is a platformer game where a ninja starts and goal is to kill all the enemies on the level, there are three levels with increasing order of difficulty. The player can jump and dash, the player kills the enimies by dashing, and the enemy can kill the player by shooting, Once all the enimes in a level are killed the player proceeds to the next level.
#### Explanation of files

The project folder has two Directories and two python files
the file **editor.py** is the level editor of the game for designing levels and loading in the assets and sprites. 

##### *main.py*
The file **main.py** is the game, the game is intiated by running this file on the terminal, the file starts with required imports of various libiraries such as Pygame, math, random, os, sys for python module. Then function and class from scripts folder are imported(descrption of these will be below).

Then the file start with creating **class Game**, this class runs the game, intialls it loads in the assets such as images, sounds, tilemaps, create timers for clock for game loop.

this class has a **load level** function which loads the tilemap(the level is designed as tiles with map co-ordinates of the tiles as 'json' file using the level editor), it also create a list of enemies on the level, it also tracks the players status withe variable 'Dead', it tracks the trastion of the level using variable 'transtion'.

the next function is **run**, this has the game loop using *while True* loop, the display is drawn with display function from pygame, the other assets are the drawn on base display by calling a display.blit function from pygame on the base display surface. the player, the enemies and tile map are rendered on the surface and the input from the user is recieved with a pygame.key function.

##### Script directory
it has six files

- clouds.py
* entities.py
+ particles.py
- sparks.py
- tilemaps.py
- utils.py

###### clouds.py
This file generates the radom clouds using the random library and giving it random speed, pos, depth creating a paralax effect.
###### particles.py
This file has the animation for when the player or the enemy dies.
###### sparks.py
This file has the animation for when the player is dashing or the enemy shoots.
###### tilemaps.py
this file is loading in the tiles, spawn hooks for the player,enemy, decor for both the game and level editor
###### utils.py
This file creates basic function for loading in images or series of images for creating animation which are used in the other files.
###### entities.py
THis file has three class:
- Physics entity(*base class*)
- Enemy(*sub class*)
- player(*sub class*)

**Physics entites :** this the base class for giving physics to the player and the enemy, There are rectangles drawn around the player and enemy and tiles such as ground and wall, collision between the different rect are checked in the loop, the rectangles are drawn with rect function, collision is checke with rect function. The gravity is done providing a standard velocity downward but if th collision with the ground are wall it is set to zero.

**Enemy :** this sub class inherits from the physics entities, it gives basic walking pattern for the enemies and function for shooting projectile when the playes within the range and check function so the enimes move with thepaticular area

**PLayer :** this clas also inherits from physics entity it geves the player the abilty to move and dash, it has jump fuction, dash fuction. the jump function is implemented by creatin a negative velocity on opposite to gravity and dash is implemented by increasing the velocity. the dash also function as a way of colliding with the enemy there by creating a way to attack enemies.

##### Data directory
THis directory has three assets files, 

The **images** contain the pixelart for the various images including player, ememies, clouds, particles, sparks, tiles for making maps, background images

The **map** contains the created maps in 'json' format.

The **sfx** contains the sound files for the various function.

This concludes thes readme, i WOULD LIKE TO THANK DAVID FOR TEACHING THIS WONDEFULL COURSE. CARTER, BRAIN YU  FOR THE ADDTIONAL HELP AND PSETS. THE YOUTUBER 'DAFLUFFYPOTATO' FOR THIS TUTORIAL AND ASSETS

THANK YOU! CS50...
